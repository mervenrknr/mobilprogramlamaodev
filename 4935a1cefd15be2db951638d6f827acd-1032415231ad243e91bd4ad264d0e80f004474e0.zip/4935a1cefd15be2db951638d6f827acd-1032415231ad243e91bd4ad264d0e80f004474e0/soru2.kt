class soru2ve3{
    // Ekrandan girilen sayının mükemmel sayı olup olmadığını
// bulan programın kotlin kodunu yazınız.
// (Mükemmel sayı, kendisini tam bölen sayıların toplamı,
// kendine eşit olan sayılardır.
// Örnek 28’dir. 1+2+4+7+14 = 28)

    System.out.println("Bir sayı giriniz: ")
    val input = readLine()
    val number = input?.toInt()

    if (number == null) {
        System.out.println("Lütfen bir sayı giriniz.")
        return
    }

    var sum = 0
    for (i in 1 until number) {
        if (number % i == 0) {
            sum += i
        }
    }

    if (sum == number) {
        System.out.println("$number mükemmel sayıdır.")
    } else {
        System.out.println("$number mükemmel sayı değildir.")
    }
    // 3.soruu : 7 değerinin faktoriyelini bulan kotlin kodunu fonksiyon kullanarak yazınız
    fun main() {
        println(factorial(7))
    }

    fun factorial(num:Int):Int{
        var res = 1
        for (i in num downTo 1) {
            res *= i
        }
        return res;
    }

}